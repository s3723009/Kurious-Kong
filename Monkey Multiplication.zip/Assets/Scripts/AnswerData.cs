﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class AnswerData
{
    public string answerText;
    public bool isCorrect;

}